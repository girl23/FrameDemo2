//
//  MCAppDelegate.h
//  MicroClassroom
//
//  Created by wdwk on 2017/3/3.
//  Copyright © 2017年 wksc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MCAppDelegate : UIResponder<UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;
@end
