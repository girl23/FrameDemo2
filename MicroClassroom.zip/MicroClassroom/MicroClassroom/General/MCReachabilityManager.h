//
//  MCReachabilityManager.h
//  MicroClassroom
//
//  Created by wdwk on 2017/3/8.
//  Copyright © 2017年 wksc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MCReachabilityManager : NSObject
+(instancetype)shareReachabilityManager;
@end
