//
//  MCNavigationController.h
//  MicroClassroom
//
//  Created by wdwk on 2017/3/6.
//  Copyright © 2017年 wksc. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface MCNavigationController : UINavigationController<UINavigationControllerDelegate>

@end
