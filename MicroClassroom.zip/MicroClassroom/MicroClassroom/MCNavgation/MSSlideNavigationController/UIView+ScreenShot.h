//
//  Created by marco on 25/05/13.
//
//
//


#import <Foundation/Foundation.h>

@interface UIView (ScreenShot)

+ (UIImage *)screenShotForView:(UIView *)view;
- (UIImage *)screenShot;

@end
