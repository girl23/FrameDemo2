//
//  MCNavigationController.m
//  MicroClassroom
//
//  Created by wdwk on 2017/3/6.
//  Copyright © 2017年 wksc. All rights reserved.
//

#import "MCNavigationController.h"
@interface MCNavigationController ()

@end

@implementation MCNavigationController

@end
