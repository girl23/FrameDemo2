//
//  WLSecondViewController.h
//  WLCustomTabbar
//
//  Created by ZhengZhong on 2016/11/22.
//  Copyright © 2016年 WenLong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MCBaseViewController.h"
@interface WLSecondViewController :MCBaseViewController

@end
