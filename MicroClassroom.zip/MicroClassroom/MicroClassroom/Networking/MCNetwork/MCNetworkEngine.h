//
//  SFCFCNetworkEngine.h
//  SinaFreshCity
//
//  Created by 飞 光普 on 14-8-7.
//  Copyright (c) 2014年 sina.com. All rights reserved.
//



#import "SANetworkEngine.h"
#import "SANetworkOperation.h"
typedef void (^SFCFCNetworkEngineCallback)(id resp, NSError *error);

@interface MCNetworkEngine :SANetworkEngine
+ (instancetype)defaultEngine;
/*
 *	@brief	2.1	基础数据接口
 *
 *	@param 	nil
 *
 *	@return	SANetworkOperation
 */
- (SANetworkOperation *)getFaoundationDateWithCallback:(SFCFCNetworkEngineCallback)callback;

/*
 *	@brief	2.2.1	首页广告 
 *
 *	@param 	nil
 *
 *	@return	SANetworkOperation
 */
- (SANetworkOperation *)getHomeAdWithCallback:(SFCFCNetworkEngineCallback)callback;

@end
