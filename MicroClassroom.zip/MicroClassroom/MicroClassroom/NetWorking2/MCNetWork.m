//
//  MCNetWork.m
//  MicroClassroom
//
//  Created by wdwk on 2017/6/6.
//  Copyright © 2017年 wksc. All rights reserved.
//

#import "MCNetWork.h"

@interface MCNetWork()

@property(nonatomic, strong)NSString * hostName;

@end
@implementation MCNetWork

+(instancetype)shareNetwork
{
    static MCNetWork * network=nil;
    static dispatch_once_t once;
    __weak typeof (self) weakSelf=self;
    dispatch_once(&once, ^{
        network=[MCNetWork new];

      
    });
    return network ;
}
//网络监测；
-(void)networkReachibliyty{
    
    [[AFNetworkReachabilityManager sharedManager] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        switch (status)
        {
            case AFNetworkReachabilityStatusUnknown:        {
                [SVProgressHUD showWithStatus:@"未知网络"];
                break;
            }
            case AFNetworkReachabilityStatusNotReachable:        {
                [SVProgressHUD showWithStatus:@"无网络链接，请检查网络！"];
                break;
            }
                
            case AFNetworkReachabilityStatusReachableViaWWAN:        {
                [SVProgressHUD showWithStatus:@"正在使用流量"];
                break;
            }
            case AFNetworkReachabilityStatusReachableViaWiFi:        {
                
                [SVProgressHUD showWithStatus:@"正在使用WI-FI"];
                break;
            }
                
        }
        
        [self performSelector:@selector(delayDismissSV) withObject:self afterDelay:2.5];
        
    }];
    // 启动监测
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];

}
-(void)delayDismissSV
{
    [SVProgressHUD dismiss];
}

-(NSURLSessionTask *)managerDownloadWithSourcePath:(NSString *)sourcePath savePath:(NSString *)savePath downloadProgress:(downloadProgress)progress downloadComplete:(downloadComplete)complete{
    AFHTTPSessionManager * manager=[AFHTTPSessionManager manager];
    NSURLRequest * request=[NSURLRequest requestWithURL:[NSURL URLWithString:sourcePath] ];
 

    NSURLSessionDownloadTask *downloadTask=[manager downloadTaskWithRequest:request progress:^(NSProgress * _Nonnull downloadProgress) {
        progress(downloadProgress);

        
    } destination:^NSURL * _Nonnull(NSURL * _Nonnull targetPath, NSURLResponse * _Nonnull response) {
        
//        
        //       1、找到沙盒文件 YES表示是否返回完整的路径； 2、添加路径建议的路径response.suggestedFilename；
        
        NSString * location=[savePath stringByAppendingPathComponent:response.suggestedFilename];
        
        
        NSURL * url=[NSURL fileURLWithPath:location];
        
        //block文件相让返回一个放置下载文件的位置；
        return url;
        
    } completionHandler:^(NSURLResponse * _Nonnull response, NSURL * _Nullable filePath, NSError * _Nullable error) {
//        filePath就是上面要返回的值，如果上面返回的值为nil,那么在这filePath就为空；
        complete(response,filePath,error);

    }];
    [downloadTask resume];
     return nil;
}
//可设置是POST还是GET
-(NSURLSessionTask *)managerWithPath:(NSString *)path params:(NSMutableDictionary *)params httpMethod:(NSString *)method callback:(NetworkCallback)callback{
    
    //    定义一个管理器
    AFHTTPSessionManager * manager=[AFHTTPSessionManager manager];
    // 设置序列化
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/html", @"text/plain", @"text/xml", @"application/json", nil];
    self.hostName=KFS_SERVER_ADDRESS;
    NSString *urlString = [NSString stringWithFormat:@"%@%@",KFS_SERVER_ADDRESS, path];
    
    NSURLSessionTask * task=nil;
    
    if ([method isEqualToString:@"GET"]) {
      task=[manager GET:urlString parameters:params success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
          
            callback(responseObject, nil);
          
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            
            callback(task,error);
            
        }];
    }
    else
    {
       task=[manager POST:urlString parameters:params success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
           
           callback(responseObject, nil);
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            
            callback(task,error);
            
        }];
    }
    return task;
}
-(NSURLSessionTask *)getFaoundationDateWithCallback:(NetworkCallback)callback{
    NSMutableDictionary *params = [@{@"action" : @""} mutableCopy];
    return [self managerWithPath:@"/init.php" params:params httpMethod:@"GET" callback:callback];
}
-(NSURLSessionTask *)getHomeAdWithCallback:(NetworkCallback)callback{
    NSMutableDictionary *params = [@{@"action" : @"adinfo"} mutableCopy];
    return [self managerWithPath:@"/home.php" params:params httpMethod:@"GET" callback:callback];

}
@end
