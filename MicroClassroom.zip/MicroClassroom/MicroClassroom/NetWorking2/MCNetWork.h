//
//  MCNetWork.h
//  MicroClassroom
//
//  Created by wdwk on 2017/6/6.
//  Copyright © 2017年 wksc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"

typedef void(^NetworkCallback)(id resp, NSError *error);
typedef void(^downloadProgress)(NSProgress *progress);
typedef void(^downloadComplete)(NSURLResponse * _Nonnull response, NSURL * _Nullable filePath, NSError * _Nullable error);
@interface MCNetWork : NSObject
//@property(nonatomic, assign)MCNetworkReachabilityStatus status;
+(instancetype)shareNetwork;
-(void)networkReachibliyty;
-(NSURLSessionTask *)getFaoundationDateWithCallback:(NetworkCallback)callback;
-(NSURLSessionTask *)getHomeAdWithCallback:(NetworkCallback)callback;
-(NSURLSessionTask *)managerDownloadWithSourcePath:(NSString *)sourcePath savePath:(NSString *)savePath downloadProgress:(downloadProgress)progress downloadComplete:(downloadComplete)complete;
@end
