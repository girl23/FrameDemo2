//
//  WLThirdViewController.m
//  WLCustomTabbar
//
//  Created by ZhengZhong on 2016/11/25.
//  Copyright © 2016年 WenLong. All rights reserved.
//

#import "WLThirdViewController.h"

@interface WLThirdViewController ()

@end

@implementation WLThirdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor greenColor]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
