//
//  MCUnderBannerButton.h
//  MicroClassroom
//
//  Created by wdwk on 2017/3/6.
//  Copyright © 2017年 wksc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MCUnderBannerButton : UIView
@property (weak, nonatomic) IBOutlet UIImageView *imgeView;
@property (weak, nonatomic) IBOutlet UILabel *lable;
@end
